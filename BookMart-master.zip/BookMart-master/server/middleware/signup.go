package middleware

import (
	"context"
	"encoding/json"
	"log"
	"net/http"

	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/nchalla5/react-go-app/models"
	"github.com/nchalla5/react-go-app/storage"
	"golang.org/x/crypto/bcrypt"
)

func Signup(w http.ResponseWriter, r *http.Request) {
	//w.Write([]byte("Welcome to the Login Page"))
	var details models.UserDetails
	err := json.NewDecoder(r.Body).Decode(&details)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(details.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "Failed to hash password", http.StatusInternalServerError)
		return
	}
	details.Password = string(hashedPassword)

	if !isAWSMode() {
		err = localStore.CreateUser(details)
		if err != nil {
			if err == storage.ErrUserExists {
				http.Error(w, "User already exists", http.StatusConflict)
				return
			}
			http.Error(w, "Failed to create user", http.StatusInternalServerError)
			return
		}

		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]string{"status": "success", "message": "success"})
		return
	}

	loadEnv()
	cfg, err := config.LoadDefaultConfig(context.TODO(),
		config.WithRegion("us-west-1"), // Our AWS region
	)
	if err != nil {
		log.Fatalf("Unable to load SDK config, %v", err)
	}
	svc := dynamodb.NewFromConfig(cfg)
	result, err := svc.GetItem(context.TODO(), &dynamodb.GetItemInput{
		TableName: aws.String("Credentials"),
		Key: map[string]types.AttributeValue{
			"UserName": &types.AttributeValueMemberS{Value: details.Email},
		},
	})
	if err != nil {
		log.Printf("Failed to query user: %v", err)
		http.Error(w, "Database query failed", http.StatusInternalServerError)
		return
	} else if result.Item != nil {
		http.Error(w, "User already exists", http.StatusConflict)
		return
	}
	insertCredential(svc, details)
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"status": "success", "message": "success"})
}

func insertCredential(svc *dynamodb.Client, details models.UserDetails) {
	_, err := svc.PutItem(context.TODO(), &dynamodb.PutItemInput{
		TableName: aws.String("Credentials"),
		Item: map[string]types.AttributeValue{
			"Name":     &types.AttributeValueMemberS{Value: details.Name},
			"UserName": &types.AttributeValueMemberS{Value: details.Email},
			"Password": &types.AttributeValueMemberS{Value: details.Password}, // Consider using a hash function
		},
	})

	if err != nil {
		log.Fatalf("Failed to insert data, %v", err)
	}

	// fmt.Println("Successfully inserted credential")
}
